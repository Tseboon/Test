package graficos;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class HojaSprites {
	private final int ancho;
	private final int alto;
	public final int[] pixeles;

	// Hojas de Sprites
	public static HojaSprites iconos = new HojaSprites("/texturas/Sheet.png", 64, 32);

	// Fin de Hojas Sprites

	public HojaSprites(final String ruta, final int _ancho, final int _alto) {
		ancho = _ancho;
		alto = _alto;

		pixeles = new int[ancho * alto];

		BufferedImage imagen;

		try {
			imagen = ImageIO.read(HojaSprites.class.getResource(ruta));
			imagen.getRGB(0, 0, _ancho, _alto, pixeles, 0, _ancho);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public int getAncho() {
		return ancho;
	}
}
