package graficos;

public class Sprite {
	private final int lado;
	private int x;
	private int y;

	public int[] pixeles;
	private final HojaSprites hoja;

	// Colecci�n de Sprites
	public static Sprite playerU = new Sprite(16, 0, 0, HojaSprites.iconos);
	// Fin de la colecci�n

	public Sprite(final int _lado, final int fila, final int columna, final HojaSprites _hoja) {
		lado = _lado;
		pixeles = new int[_lado * _lado];

		x = columna * _lado;
		y = fila * _lado;
		hoja = _hoja;

		for (int _y = 0; _y < _lado; _y++) {
			for (int _x = 0; _x < _lado; _x++) {
				pixeles[_x + _y * lado] = _hoja.pixeles[(_x + x) + (_y + y) * hoja.getAncho()];
			}
		}
	}
}
