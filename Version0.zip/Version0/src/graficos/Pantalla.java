package graficos;

public class Pantalla {
	private final int ancho;
	private final int alto;

	public final int[] pixeles;

	public Pantalla(final int _ancho, final int _alto) {
		ancho = _ancho;
		alto = _alto;
		pixeles = new int[_ancho * _alto];
	}

	public void limpiar() {
		for (int i = 0; i < ancho * alto; i++) {
			pixeles[i] = 0;
		}
	}

	public void mostrar(final int sesgoX, final int sesgoY) {
		int posicionY;
		int posicionX;
		for (int _y = 0; _y < alto; _y++) {
			posicionY = _y + sesgoY;
			if (posicionY < 0 || posicionY >= alto) {
				continue;
			}
			for (int _x = 0; _x < ancho; _x++) {
				posicionX = _x + sesgoX;

				if (posicionX < 0 || posicionX >= ancho) {
					continue;
				}

				pixeles[posicionX + posicionY * ancho] = Sprite.playerU.pixeles[(_x & 15) + (_y & 15) * 16];
			}
		}
	}
}
