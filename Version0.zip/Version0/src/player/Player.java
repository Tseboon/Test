package player;

import java.awt.image.BufferedImage;

import mapas.Mapa;
import reglas.Reglas;

public class Player {
	public static BufferedImage imagen;

	// Propiedades del jugador
	private static byte coordenadaX;
	private static byte coordenadaY;
	private static byte direccion;
	private static byte velocidad;
	private static byte vidas;
	private static boolean movimiento;
	// Fin propiedades del jugador

	public Player(byte _coordenadaX, byte _coordenadaY, byte _direccion) {
		coordenadaX = _coordenadaX;
		coordenadaY = _coordenadaY;
		direccion = _direccion;
		vidas = 3;
		velocidad = 30;
		movimiento = false;
	}

	private void validarMovimiento(Mapa _mapa) {
		int[] _x = { 0, 1, 0, -1 };
		int[] _y = { -1, 0, 1, 0 };
		// Verifica que no se salga del mapa.
		if ((coordenadaX + _x[direccion]) >= 0 && (coordenadaX + _x[direccion]) < _mapa.getAncho()
				&& (coordenadaY + _y[direccion]) >= 0 && (coordenadaY + _y[direccion]) < _mapa.getAlto()) {
			// Verifica que no choque contra una pared.
			if (_mapa.getPosicion((coordenadaX + _x[direccion]), (coordenadaY + _y[direccion])) < Reglas.PARED) {
				movimiento = true;
			} else {
				movimiento = false;
			}
		} else {
			// En caso de salirse del mapa.
			movimiento = false;
		}
	}

	public void mover(Mapa _mapa) {
		validarMovimiento(_mapa);
		if (movimiento) {
			int[] _x = { 0, 1, 0, -1 };
			int[] _y = { -1, 0, 1, 0 };

			coordenadaX += _x[direccion];
			coordenadaY += _y[direccion];
		}
	}

	public static byte getX() {
		return coordenadaX;
	}

	public static void setX(byte _coordenadaX) {
		coordenadaX = _coordenadaX;
	}

	public static byte getY() {
		return coordenadaY;
	}

	public static void setY(byte _coordenadaY) {
		coordenadaY = _coordenadaY;
	}

	public static byte getDireccion() {
		return direccion;
	}

	public static void setDireccion(byte _direccion) {
		direccion = _direccion;
	}

	public static byte getVelocidad() {
		return velocidad;
	}

	public static void setVelocidad(byte _velocidad) {
		velocidad = _velocidad;
	}

	public static byte getVidas() {
		return vidas;
	}

	public static void setVidas(byte _vidas) {
		vidas = _vidas;
	}
}
