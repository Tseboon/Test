package reglas;

public final class Reglas {
	public static final int PARED = 100;
}
