package mapas;

import reglas.Reglas;

public class Mapa {
	private final int ANCHO;
	private final int ALTO;
	private static int[] croquis;

	public Mapa(int _ANCHO, int _ALTO) {
		ANCHO = _ANCHO;
		ALTO = _ALTO;
		croquis = new int[ANCHO * ALTO];

		// Inicializa las paredes externas del mapa
		for (int i = 0; i < ALTO; i++) {
			for (int j = 0; j < ANCHO; j++) {
				if (i == 0 || j == 0 || i == ALTO - 1 || j == ANCHO - 1) {
					croquis[j + i * ANCHO] = Reglas.PARED;
				} else {
					croquis[j + i * ANCHO] = 0;
				}
			}
		}
	}

	public int getPosicion(int _x, int _y) {
		return croquis[_x + _y * ANCHO];
	}

	public int getAncho() {
		return ANCHO;
	}

	public int getAlto() {
		return ALTO;
	}

}
